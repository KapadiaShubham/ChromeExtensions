const eleMent = `<ytd-menu-service-item-renderer
  class="style-scope ytd-menu-popup-renderer"
  use-icons=""
  system-icons=""
  role="menuitem"
  tabindex="-1"
  aria-selected="false"
  ><!--css-build:shady--><tp-yt-paper-item
    class="style-scope ytd-menu-service-item-renderer"
    role="option"
    tabindex="0"
    aria-disabled="false"
    ><!--css-build:shady-->
    <yt-icon class="style-scope ytd-menu-service-item-renderer"
      ><svg
        viewBox="0 0 24 24"
        preserveAspectRatio="xMidYMid meet"
        focusable="false"
        class="style-scope yt-icon"
        style="pointer-events: none; display: block; width: 100%; height: 100%"
      >
        <g class="style-scope yt-icon">
          <path
            d="M5,11h2v2H5V11z M15,15H5v2h10V15z M19,15h-2v2h2V15z M19,11H9v2h10V11z M22,6H2v14h20V6z M3,7h18v12H3V7z"
            class="style-scope yt-icon"
          ></path>
        </g></svg
      ><!--css-build:shady--></yt-icon
    >
    <yt-formatted-string class="style-scope ytd-menu-service-item-renderer"
      >Open transcript</yt-formatted-string
    >
  </tp-yt-paper-item>
</ytd-menu-service-item-renderer>
`

export {eleMent};
